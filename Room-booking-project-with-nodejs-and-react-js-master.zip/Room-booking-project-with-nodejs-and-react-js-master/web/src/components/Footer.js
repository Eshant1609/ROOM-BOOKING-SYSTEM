import React from 'react'

const Footer = props => (
  <footer className="footer">
    <p>Coder Academy Class Project</p>
  </footer>
)

export default Footer